function SobelConvertion(reader,my_file_name)
Bx = [2,1,0,-1,-2;2,1,0,-1,-2;4,2,0,-2,-4;2,1,0,-1,-2;2,1,0,-1,-2]; % Sobel Gx kernel mask.
By = Bx'; % Sobel Gy kernel mask.
updated_file_name="videos\"+my_file_name+"_sobel_converted";  % The new updated file name.
writer = VideoWriter(updated_file_name);
open(writer);
i=1;
while hasFrame(reader)
    img = readFrame(reader);
    grayframe=uint16(rgb2gray(img));
    Yx = filter2(Bx,grayframe); % convolve in 2d.
    Yy = filter2(By,grayframe);
    G = abs(Yy) + abs(Yx); % Find magnitude.
    G_max= max(max(G));
    coef=255/G_max;
    G=G*coef;              % Normalize the values.
    img=uint8(G);
    writeVideo(writer,img);
    disp(i)
    i=i+1;
end
close(writer)
end
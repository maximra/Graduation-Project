function  FrameDerivative(reader,my_file_name,threshold_value)
frame_zero=read(reader,1);
[Rows , Columns,~]=size((frame_zero));
frame_zero=rgb2gray(frame_zero);
writer = VideoWriter("videos\"+my_file_name+"_detect_change_1");   % The new updated file name.
writer.FrameRate = reader.FrameRate;
numFrames = floor(reader.FrameRate*reader.Duration);
open(writer)
sum=0;                   % Variable used to compare the gap.
for i=1:numFrames
modified_frame=rgb2gray(read(reader,i));
 for row=1:1:Rows
         for column=1:1:Columns
             sum=sum+(modified_frame(row,column)-frame_zero(row,column))*3;
             if(sum>threshold_value)                  % The gap is larger than the threshold value.
                 modified_frame(row,column)=255;      
             else                                     % The gap is not larger than the threshold value.
                 modified_frame(row,column)=0;        
             end
             sum=0;
         end
 end
 writeVideo(writer,modified_frame);
 disp(i);
end

close(writer)
end
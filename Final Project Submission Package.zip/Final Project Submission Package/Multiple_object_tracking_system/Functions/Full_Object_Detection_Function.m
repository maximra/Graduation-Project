%% Explanation of some variables:
% frame --> each seperate frame with sobel transform
% frame_zero --> the first frame in the video with the sobel transform
% black_white_frame --> white and black image (255 or 0 values only) and
% not other values too because this time around there is no video
% compression(no intermediate files were generated). 
% original_video_frame --> contains the original video frame
% modified_frame --> the original video frame+ highlighted objects
function object_counter= Full_Object_Detection_Function(reader,my_file_name,threshold_radius,Thickness,threshold_value) 
%% Different variables we need before the main loop:
%% Angular filtraion function variables:
frame=read(reader,1);
[Rows , Columns,~]=size((frame));
writer = VideoWriter("videos\"+my_file_name+"_detect_objects_in_original_video");  % The new updated file name.
writer.FrameRate = reader.FrameRate;
numFrames = floor(reader.FrameRate*reader.Duration);
object_counter=zeros(1,numFrames-2); % we will use this vairalbe to count how many objects appear in each frame.
reader2= VideoReader(my_file_name+".mp4"); % Responsible for the original video.
t=linspace(0,pi,100); % Variable that is responsible for the angles of the half circle.
y1=cos(t);
y2=sin(t);
R1=1;
R2=1;
key=0;
correct_position=0;
shift_constant= Thickness*100; % used to determine whether or not we need to shift the rectangle 
%% Frame derivative variable:
sum=0;   % Variable used to compare the gap.
%% Sobel variables
% Note: The first frame is generated here aswell, which will be used in the
% main loop.
Bx = [2,1,0,-1,-2;2,1,0,-1,-2;4,2,0,-2,-4;2,1,0,-1,-2;2,1,0,-1,-2]; % Sobel Gx kernel mask.
By = Bx'; % Sobel Gy kernel mask.
frame_zero=uint16(rgb2gray(frame));
Yx = filter2(Bx,frame_zero); % convolve in 2d.
Yy = filter2(By,frame_zero);
G = abs(Yy) + abs(Yx); % Find magnitude.
G_max= max(max(G));
coef=255/G_max;
G=G*coef;              % Normalize the values.
frame_zero=uint8(G);
open(writer)
%% New variables:
videoPlayer=vision.VideoPlayer; % This object will allow us to play the video in real time
%% The main function: 
% In this main loop, all three functions are perfomed one after another for
% a SINGLE FRAME. Each iteration of the loop a different frames is
% processed by the functions. The moment a processed frame is generated,the 
% VideoPlayer displays that frame on screen using the step() function.
% Everything else is exactly the same.
% There is a possiblity that the output results will be slightly different
% because there in no video compression.
for i=1:numFrames-2  % The main function loop.
 frame=uint16(rgb2gray(read(reader,i)));
 Yx = filter2(Bx,frame); % convolve in 2d
 Yy = filter2(By,frame);
 G = abs(Yy) + abs(Yx); % Find magnitude
 G_max= max(max(G));
 coef=255/G_max;  
 G=G*coef;              % Normalize the values.
 frame=uint8(G);
 black_white_frame=frame;
 for row=1:1:Rows
         for column=1:1:Columns
             sum=sum+(black_white_frame(row,column)-frame_zero(row,column))*3;
             if(sum>threshold_value)                    % The gap is larger than the threshold value.
                 black_white_frame(row,column)=255;
             else                                       % The gap is not larger than the threshold value.
                 black_white_frame(row,column)=0; 
             end
             sum=0;
         end
         
 end
 modified_frame=uint8(zeros(Rows,Columns));
    for row=1:Rows-Thickness-1
        for column=1:Columns-Thickness-1
            if black_white_frame(row,column)>=200   % Entered sub loop, generating half circle around the pixel.
                black_white_frame(row,column)=0;
                while(1)
                    for k=1:numel(y1)
                     if(row-R2-Thickness>=2 && column-R1-Thickness>=2)
                     for r=0:Thickness
                     if black_white_frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))>=200
                         if k>90
                              correct_position=correct_position+3;
                         elseif k>70
                             correct_position=correct_position+2;
                         elseif k>=50
                             correct_position=correct_position+1;
                         end
                         key=1;
                         break;
                     elseif black_white_frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))==100 % skip this angle.
                         key=0;
                         break;
                     end
                     end
                     end
                    end
                    if(key==0)
                    for k=1:numel(y1)
                        if(row-R2-Thickness>=2 && column-R1-Thickness>=2)
                        for r=0:Thickness
                         black_white_frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))=100; % Generate a half circle of value 100 around the current detected pixel mesh.
                        end
                        end
                    end
                        break; 
                    end
                    key=0;
                    for k=1:numel(y1)
                        for r=0:Thickness
                         black_white_frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))=0; % Nulify the values on the current half circle.
                        end
                    end
                    if(row+R2+2*Thickness<Rows)
                        R2=R2+Thickness;
                    end
                    if(column+R1+2*Thickness<Columns)
                        R1=R1+Thickness;
                    end
                end
            end
            if R1>Thickness
                R1=R1-Thickness;
            end
            if R2>Thickness
                R2=R2-Thickness;
            end
            R=max(R1,R2);
            if(R>threshold_radius )       % Radius is larger than the threshold radius, object detected.
                for r2=-(R2-1):R2-1
                   for r1=-(R1-1):R1-1
                        black_white_frame(row+r2,column+r1)=100;  % Highlight the area around the center point of the detected object as not usable anymore.
                    end
                end
                if correct_position>R1*shift_constant     % Position needs to be shifted.
                    correct_position=R1;
                else
                    correct_position=0;
                end
                modified_frame=insertShape(modified_frame,'Rectangle',[column-correct_position row  R1 R2],'LineWidth',1); % Draw rectable around the object.
                modified_frame=insertShape(modified_frame,'Rectangle',[column-correct_position row  10 10],'LineWidth',5);
                object_counter(i)=object_counter(i)+1;
                disp("entered here")
            end
            correct_position=0;       % Reset variables.
            R1=1;
            R2=1;
        end
    end
     original_video_frame=read(reader2,i);  
     modified_frame=original_video_frame+modified_frame;
     writeVideo(writer,modified_frame);
     step(videoPlayer,modified_frame);           % Display output frame on screen.
     disp(i);
end 
close(writer);
end
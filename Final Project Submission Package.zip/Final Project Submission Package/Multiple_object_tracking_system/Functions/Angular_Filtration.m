
%% This function has multiple parameters that effect the final result:
% The threshold radius is the minimum required radius to highlight an
% object.
% The function generates 100 samples per each half circle to look for a
% value which is higher than 200 (not 255 because video compression can
% generate other values).
% The Thickness can play an important role when the frame derivate function
% has filterred too much of the original object and created certain gaps
% inside the object itself. A higher thickness generally can improve
% results, but there is a possibility that it can combine two objects into
% one object or even consider random noise as part of an object.
% The object_counter returns the number of detected objects as a function
% of time. The data it returns is not filtered.
function object_counter= Angular_Filtration(reader,my_file_name,threshold_radius,Thickness) 
frame=read(reader,1);
[Rows , Columns,~]=size((frame));
writer = VideoWriter("videos\"+my_file_name+"_detect_objects_in_original_video"); % he new updated file name.
writer.FrameRate = reader.FrameRate;
numFrames = floor(reader.FrameRate*reader.Duration);
object_counter=zeros(1,numFrames); % we will use this variable to count how many objects appear in each frame.
reader2= VideoReader(my_file_name+".mp4"); % Responsible for the original video.
t=linspace(0,pi,100); % Variable that is responsible for the angles of the half circle.
y1=cos(t);
y2=sin(t);
R1=1;
R2=1;
key=0;
correct_position=0;
open(writer)
shift_constant= Thickness*100; % used to determine whether or not we need to shift the rectangle. 
for i=1:numFrames
    frame=rgb2gray(read(reader,i));
    modified_frame=uint8(zeros(Rows,Columns));
    for row=1:Rows-Thickness-1
        for column=1:Columns-Thickness-1
            if frame(row,column)>=200  % Entered sub loop, generating half circle around the pixel.
                frame(row,column)=0;
                while(1)
                    for k=1:numel(y1)
                         if(row-R2-Thickness>=2 && column-R1-Thickness>=2)
                            for r=0:Thickness
                                 if frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))>=200
                                     if k>90
                                         correct_position=correct_position+3;
                                     elseif k>70
                                         correct_position=correct_position+2;
                                     elseif k>=50
                                         correct_position=correct_position+1;
                                     end
                                     key=1;
                                     break;
                                 elseif frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))==100 % skip this angle.
                                     key=0;
                                     break;
                                 end
                             end
                          end
                    end
                    if(key==0)
                        for k=1:numel(y1)
                            if(row-R2-Thickness>=2 && column-R1-Thickness>=2)
                              for r=0:Thickness
                                  frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))=100; % Generate a half circle of value 100 around the current detected pixel mesh.
                              end
                            end
                        end
                        break; 
                    end
                    key=0;
                    for k=1:numel(y1)
                        for r=0:Thickness
                         frame(round(row+(R2+r)*y2(k)),round(column+(R1+r)*y1(k)))=0; % Nulify the values on the current half circle.
                        end
                    end
                    if(row+R2+2*Thickness<Rows)
                        R2=R2+Thickness;
                    end
                    if(column+R1+2*Thickness<Columns)
                        R1=R1+Thickness;
                    end
                end
            end
            if R1>Thickness
                R1=R1-Thickness;
            end
            if R2>Thickness
                R2=R2-Thickness;
            end
            R=max(R1,R2);
            if(R>threshold_radius )             % Radius is larger than the threshold radius, object detected.
                for r2=-(R2-1):R2-1
                   for r1=-(R1-1):R1-1
                        frame(row+r2,column+r1)=100;        % Highlight the area around the center point of the detected object as not usable anymore.
                    end
                end
                if correct_position>R1*shift_constant       % Position needs to be shifted.
                    correct_position=R1;
                else
                    correct_position=0;
                end
                modified_frame=insertShape(modified_frame,'Rectangle',[column-correct_position row  R1 R2],'LineWidth',1); % Draw rectable around the object.
                modified_frame=insertShape(modified_frame,'Rectangle',[column-correct_position row  10 10],'LineWidth',5);
                object_counter(i)=object_counter(i)+1;
                disp("entered here")
            end
            correct_position=0;   % Reset variables.
            R1=1;
            R2=1;
        end
    end
     original_video_frame=read(reader2,i);  
     modified_frame=original_video_frame+modified_frame;
     writeVideo(writer,modified_frame);
     disp(i);
end
close(writer);
end